import { useState } from 'react';

const ProfileForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    surname: '',
    age: '',
    phoneNumber: '',
    preferredLanguages: '',
    skills: '',
    projectsDone: '',
    linkedinProfile: '',
    githubProfile: ''
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }

    if (!formData.surname.trim()) {
      newErrors.surname = 'Surname is required';
    }

    const age = parseInt(formData.age);
    if (!formData.age || isNaN(age) || age <= 10) {
      newErrors.age = 'Age must be greater than 10';
    }

    if (!formData.phoneNumber.trim() || formData.phoneNumber.length < 10) {
      newErrors.phoneNumber = 'Phone number must be at least 10 digits';
    }

    if (!formData.preferredLanguages.trim()) {
      newErrors.preferredLanguages = 'Preferred programming languages are required';
    }

    if (!formData.skills.trim()) {
      newErrors.skills = 'Skills are required';
    }

    if (!formData.projectsDone.trim()) {
      newErrors.projectsDone = 'Projects done is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      const profileData = {
        ...formData,
        age: parseInt(formData.age)
      };
      localStorage.setItem('userProfile', JSON.stringify(profileData));
      localStorage.setItem('profileCompleted', 'true');
      if (onSubmit) {
        onSubmit(profileData);
      }
    }
  };

  const isFormValid = () => {
    return formData.firstName.trim() &&
           formData.surname.trim() &&
           formData.age &&
           parseInt(formData.age) > 10 &&
           formData.phoneNumber.trim().length >= 10 &&
           formData.preferredLanguages.trim() &&
           formData.skills.trim() &&
           formData.projectsDone.trim();
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-[560px] h-full flex flex-col animate-fade-slide-up">
      <div className="profile-scroll-area flex-1 min-h-0 overflow-y-auto pr-2">
        <div className="p-6 space-y-4">
          <div>
            <label htmlFor="firstName" className="block text-sm text-gray-600 mb-1.5 text-left">
              First Name
            </label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 ${errors.firstName ? 'border-red-300' : ''}`}
            />
            {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
          </div>

          <div>
            <label htmlFor="surname" className="block text-sm text-gray-600 mb-1.5 text-left">
              Surname
            </label>
            <input
              type="text"
              id="surname"
              name="surname"
              value={formData.surname}
              onChange={handleChange}
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 ${errors.surname ? 'border-red-300' : ''}`}
            />
            {errors.surname && <p className="text-red-500 text-sm mt-1">{errors.surname}</p>}
          </div>

          <div>
            <label htmlFor="age" className="block text-sm text-gray-600 mb-1.5 text-left">
              Age
            </label>
            <input
              type="number"
              id="age"
              name="age"
              value={formData.age}
              onChange={handleChange}
              min="11"
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 ${errors.age ? 'border-red-300' : ''}`}
            />
            {errors.age && <p className="text-red-500 text-sm mt-1">{errors.age}</p>}
          </div>

          <div>
            <label htmlFor="phoneNumber" className="block text-sm text-gray-600 mb-1.5 text-left">
              Phone Number
            </label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 ${errors.phoneNumber ? 'border-red-300' : ''}`}
            />
            {errors.phoneNumber && <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>}
          </div>

          <div>
            <label htmlFor="preferredLanguages" className="block text-sm text-gray-600 mb-1.5 text-left">
              Preferred Programming Languages
            </label>
            <input
              type="text"
              id="preferredLanguages"
              name="preferredLanguages"
              value={formData.preferredLanguages}
              onChange={handleChange}
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 ${errors.preferredLanguages ? 'border-red-300' : ''}`}
            />
            {errors.preferredLanguages && <p className="text-red-500 text-sm mt-1">{errors.preferredLanguages}</p>}
          </div>

          <div>
            <label htmlFor="skills" className="block text-sm text-gray-600 mb-1.5 text-left">
              Skills
            </label>
            <textarea
              id="skills"
              name="skills"
              value={formData.skills}
              onChange={handleChange}
              rows="4"
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 resize-none ${errors.skills ? 'border-red-300' : ''}`}
            />
            {errors.skills && <p className="text-red-500 text-sm mt-1">{errors.skills}</p>}
          </div>

          <div>
            <label htmlFor="projectsDone" className="block text-sm text-gray-600 mb-1.5 text-left">
              Projects Done
            </label>
            <textarea
              id="projectsDone"
              name="projectsDone"
              value={formData.projectsDone}
              onChange={handleChange}
              rows="4"
              className={`w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200 resize-none ${errors.projectsDone ? 'border-red-300' : ''}`}
            />
            {errors.projectsDone && <p className="text-red-500 text-sm mt-1">{errors.projectsDone}</p>}
          </div>

          <div>
            <label htmlFor="linkedinProfile" className="block text-sm text-gray-600 mb-1.5 text-left">
              LinkedIn Profile <span className="text-gray-400">(optional)</span>
            </label>
            <input
              type="url"
              id="linkedinProfile"
              name="linkedinProfile"
              value={formData.linkedinProfile}
              onChange={handleChange}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200"
            />
          </div>

          <div>
            <label htmlFor="githubProfile" className="block text-sm text-gray-600 mb-1.5 text-left">
              GitHub Profile <span className="text-gray-400">(optional)</span>
            </label>
            <input
              type="url"
              id="githubProfile"
              name="githubProfile"
              value={formData.githubProfile}
              onChange={handleChange}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all duration-200"
            />
          </div>

          <div className="mt-6 pb-2">
            <button
              type="submit"
              disabled={!isFormValid()}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Submit Profile
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default ProfileForm;

