import { useState } from 'react';
import { CheckCircle, ArrowRight, ArrowLeft, Sparkles, Users, Target, Rocket } from 'lucide-react';

const OnboardingWizard = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      icon: <Sparkles className="w-16 h-16 text-primary-500" />,
      title: "Welcome to Your AI Project Mentor",
      description: "Get step-by-step guidance to complete your projects successfully with AI-powered planning and tracking.",
    },
    {
      icon: <Users className="w-16 h-16 text-accent-500" />,
      title: "Collaborate with Your Team",
      description: "Work together seamlessly with shared project plans, progress tracking, and team chat.",
    },
    {
      icon: <Target className="w-16 h-16 text-success-500" />,
      title: "AI-Powered Roadmaps",
      description: "Get personalized project roadmaps generated based on your idea and team size.",
    },
    {
      icon: <Rocket className="w-16 h-16 text-primary-600" />,
      title: "Track Your Progress",
      description: "Update your progress and receive AI feedback and suggestions to keep your project on track.",
    },
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="w-full h-full flex flex-col p-6 animate-fade-in">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          {steps.map((_, index) => (
            <div key={index} className="flex items-center flex-1">
              <div
                className={`flex-1 h-2 rounded-full ${
                  index <= currentStep
                    ? 'bg-gradient-to-r from-primary-500 to-accent-500'
                    : 'bg-gray-200'
                }`}
              />
              {index < steps.length - 1 && (
                <div className="w-4" />
              )}
            </div>
          ))}
        </div>
        <div className="text-center text-sm text-gray-600">
          Step {currentStep + 1} of {steps.length}
        </div>
      </div>

      {/* Step Content */}
      <div className="text-center mb-8 animate-slide-up flex-1">
        <div className="flex justify-center mb-6">
          {steps[currentStep].icon}
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          {steps[currentStep].title}
        </h2>
        <p className="text-lg text-gray-600 max-w-md mx-auto">
          {steps[currentStep].description}
        </p>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center">
        <button
          onClick={prevStep}
          disabled={currentStep === 0}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
            currentStep === 0
              ? 'text-gray-400 cursor-not-allowed'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <ArrowLeft className="w-5 h-5" />
          Previous
        </button>

        <button
          onClick={nextStep}
          className="btn-primary flex items-center gap-2"
        >
          {currentStep === steps.length - 1 ? (
            <>
              Get Started
              <CheckCircle className="w-5 h-5" />
            </>
          ) : (
            <>
              Next
              <ArrowRight className="w-5 h-5" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default OnboardingWizard;

