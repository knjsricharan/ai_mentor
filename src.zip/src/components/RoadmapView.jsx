import { useState, useEffect } from 'react';
import { CheckCircle, Circle, Clock, Sparkles, Loader } from 'lucide-react';

const RoadmapView = ({ projectId }) => {
  const [roadmap, setRoadmap] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    // TODO: Fetch roadmap from Firestore
    // For now, using mock data
    setTimeout(() => {
      setRoadmap({
        phases: [
          {
            id: '1',
            name: 'Planning & Setup',
            description: 'Initial project setup and planning phase',
            tasks: [
              { id: '1-1', name: 'Define project requirements', completed: true },
              { id: '1-2', name: 'Set up development environment', completed: true },
              { id: '1-3', name: 'Create project repository', completed: false },
            ],
          },
          {
            id: '2',
            name: 'Development',
            description: 'Core development phase',
            tasks: [
              { id: '2-1', name: 'Implement core features', completed: false },
              { id: '2-2', name: 'Write unit tests', completed: false },
              { id: '2-3', name: 'Code review and refactoring', completed: false },
            ],
          },
          {
            id: '3',
            name: 'Testing & Deployment',
            description: 'Final testing and deployment',
            tasks: [
              { id: '3-1', name: 'Integration testing', completed: false },
              { id: '3-2', name: 'Deploy to production', completed: false },
              { id: '3-3', name: 'Monitor and optimize', completed: false },
            ],
          },
        ],
      });
      setLoading(false);
    }, 1000);
  }, [projectId]);

  const toggleTask = async (phaseId, taskId) => {
    setUpdating(true);
    // TODO: Update task in Firestore
    setRoadmap(prev => ({
      ...prev,
      phases: prev.phases.map(phase =>
        phase.id === phaseId
          ? {
              ...phase,
              tasks: phase.tasks.map(task =>
                task.id === taskId
                  ? { ...task, completed: !task.completed }
                  : task
              ),
            }
          : phase
      ),
    }));
    setTimeout(() => setUpdating(false), 500);
  };

  const getProgress = () => {
    if (!roadmap) return 0;
    const totalTasks = roadmap.phases.reduce((sum, phase) => sum + phase.tasks.length, 0);
    const completedTasks = roadmap.phases.reduce(
      (sum, phase) => sum + phase.tasks.filter(task => task.completed).length,
      0
    );
    return totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <Loader className="w-12 h-12 text-primary-500 animate-spin mx-auto mb-4" />
        <p className="text-gray-600">Generating AI roadmap...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Progress Overview */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">Project Progress</h2>
          <span className="text-2xl font-bold text-primary-600">{getProgress()}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-gradient-to-r from-primary-500 to-accent-500 h-4 rounded-full transition-all duration-500"
            style={{ width: `${getProgress()}%` }}
          />
        </div>
      </div>

      {/* Roadmap Phases */}
      <div className="space-y-6">
        {roadmap.phases.map((phase, phaseIndex) => (
          <div key={phase.id} className="card">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-primary-500 to-accent-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">
                {phaseIndex + 1}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-1">{phase.name}</h3>
                <p className="text-gray-600">{phase.description}</p>
              </div>
            </div>

            <div className="space-y-3 ml-16">
              {phase.tasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => !updating && toggleTask(phase.id, task.id)}
                >
                  {task.completed ? (
                    <CheckCircle className="w-5 h-5 text-success-500 flex-shrink-0" />
                  ) : (
                    <Circle className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                  <span
                    className={`flex-1 ${
                      task.completed
                        ? 'text-gray-500 line-through'
                        : 'text-gray-900'
                    }`}
                  >
                    {task.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* AI Suggestions */}
      <div className="card bg-gradient-to-br from-primary-50 to-accent-50 border-2 border-primary-200">
        <div className="flex items-start gap-3">
          <Sparkles className="w-6 h-6 text-primary-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-bold text-gray-900 mb-2">AI Suggestion</h3>
            <p className="text-gray-700">
              Based on your progress, consider focusing on completing the Planning & Setup phase
              before moving to Development. This will ensure a solid foundation for your project.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoadmapView;

