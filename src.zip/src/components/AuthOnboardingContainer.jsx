import { useState, useEffect } from 'react';
import OnboardingWizard from './OnboardingWizard';
import Login from '../pages/Login';
import ProfileForm from './ProfileForm';

const AuthOnboardingContainer = ({ onOnboardingComplete, onAuthSuccess, initialView = 'onboarding' }) => {
  const [currentView, setCurrentView] = useState(initialView); // 'onboarding', 'auth', or 'profile'

  // If initialView is 'auth', check if user has seen onboarding
  useEffect(() => {
    if (initialView === 'auth') {
      const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
      if (!hasSeenOnboarding) {
        setCurrentView('onboarding');
      }
    }
  }, [initialView]);

  const handleOnboardingComplete = () => {
    setCurrentView('auth');
    if (onOnboardingComplete) {
      onOnboardingComplete();
    }
  };

  const handleAuthSuccess = () => {
    setCurrentView('profile');
    if (onAuthSuccess) {
      onAuthSuccess();
    }
  };

  const handleProfileSubmit = (profileData) => {
    // Profile data is already stored in localStorage
    // Do not redirect - stay in the same container
  };

  // Subtle AI-inspired geometric pattern (grid/node structure)
  const patternStyle = {
    backgroundImage: `
      linear-gradient(rgba(79,70,229,0.05) 1px, transparent 1px),
      linear-gradient(90deg, rgba(79,70,229,0.05) 1px, transparent 1px),
      radial-gradient(circle, rgba(124,58,237,0.03) 1px, transparent 1px)
    `,
    backgroundSize: '32px 32px, 32px 32px, 64px 64px',
    backgroundPosition: '0 0, 0 0, 16px 16px',
    opacity: 0.05
  };

  return (
    <div 
      className="h-screen overflow-hidden flex items-center justify-center p-4 relative" 
      style={{ 
        background: `
          radial-gradient(circle at top center, rgba(79,70,229,0.18), transparent 55%),
          radial-gradient(circle at bottom right, rgba(124,58,237,0.16), transparent 60%),
          linear-gradient(180deg, #f5f7fb 0%, #eef1f7 100%)
        `
      }}
    >
      {/* AI structure pattern overlay */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={patternStyle}
      />
      
      <div 
        className="w-full max-w-[560px] min-h-[420px] max-h-[90vh] bg-white rounded-[18px] flex flex-col relative z-10 overflow-hidden"
        style={{ boxShadow: '0 4px 16px rgba(0, 0, 0, 0.12), 0 1px 4px rgba(0, 0, 0, 0.08)' }}
      >
        {currentView === 'onboarding' ? (
          <OnboardingWizard onComplete={handleOnboardingComplete} />
        ) : currentView === 'auth' ? (
          <Login onAuthSuccess={handleAuthSuccess} />
        ) : (
          <ProfileForm onSubmit={handleProfileSubmit} />
        )}
      </div>
    </div>
  );
};

export default AuthOnboardingContainer;

