// App Configuration
// Update this file to customize your app name and branding

export const APP_CONFIG = {
  name: 'Your App Name', // Change this to your app name
  // You can also add other branding configs here like:
  // logo: '/path/to/logo.png',
  // primaryColor: '#0ea5e9',
  // etc.
};

