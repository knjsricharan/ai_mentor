import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext({});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  // Check for existing mock user in localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('mockUser');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const loginWithGoogle = async () => {
    // Static login - create a mock user object
    const mockUser = {
      uid: 'mock-user-123',
      displayName: 'Demo User',
      email: 'demo@example.com',
      photoURL: 'https://ui-avatars.com/api/?name=Demo+User&background=0ea5e9&color=fff',
    };
    
    // Store in localStorage to persist across page refreshes
    localStorage.setItem('mockUser', JSON.stringify(mockUser));
    setUser(mockUser);
    
    return mockUser;
  };

  const logout = async () => {
    // Clear mock user
    localStorage.removeItem('mockUser');
    setUser(null);
  };

  const value = {
    user,
    loginWithGoogle,
    logout,
    loading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

